/*Represent a given graph using adjacency matrix/list to perform DFS 
and using adjacency list to perform BFS. Use the map of the area 
around the college as the graph. Identify the prominent land marks as 
nodes and perform DFS and BFS on that.*/

