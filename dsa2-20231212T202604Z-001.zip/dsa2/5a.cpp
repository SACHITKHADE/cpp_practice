/*Construct an expression tree from the given prefix expression eg. +--
a*bc/def and traverse it using post order traversal (non recursive) and 
then delete the entire tree.*/

#include<iostream>

#include<cstring>

#include<stack>

using namespace std;

class node{

               char data;

               node*left;

               node*right;

               public:

               node(){

                              left=NULL;

                              right=NULL;

               }             

               friend class exptree;

};

class exptree{

               node*root;

               public:

               node*getroot(){

                              return root;

               }

               void create(){

                              stack<node* >s;

                              char prefix[100], ch;

                              node*curr,*leftside,*rightside;

                              cout<<"enter the prefix expression\n";

                              cin>>prefix;

                              int i=strlen(prefix);

                              i=i-1;

                              for(int j=i;j>=0;j--){

                                             ch=prefix[j];

                                             node *temp=new node;

                                             temp->data=ch;

                                             if(ch >='a'&& ch<='z'){

                                                            s.push(temp);

                                             }

                                             else{

                                                            leftside=s.top();

                                                            s.pop();

                                                            rightside=s.top();

                                                            s.pop();

                                                            temp->left=leftside;

                                                            temp->right=rightside;

                                                            s.push(temp);

                                             }

                              }

                              root=s.top();

                              s.pop();

               }

               void nonpostorder(node *root){

                              stack<node *>s1;

                              stack<node *>s2;

                              node *t=root;

                              s1.push(t);

                              while(!s1.empty()){

                                             t=s1.top();

                                             s1.pop();

                                             s2.push(t);

                                             if(t->left!=NULL)

                                             s1.push(t->left);

                                             if(t->right!=NULL)

                                             s1.push(t->right);

                              }

                              while(!s2.empty()){

                                             root=s2.top();

                                             s2.pop();

                                             cout<<root->data<<" ";

                              }

                              }

                              void postorder(node*root){

                                  if(root!=NULL){

                                      postorder(root->left);

                                      postorder(root->right);

                                      cout<<root->data;

                                  }

                              }

               };           

 

int main(){

               int ch;

               exptree e1;

               while(1){

               cout<<"1.create an expression tree\n2.postorder traversal\n3.delete the tree\n";

               cout<<"\nenter your choice \n";

               cin>>ch;

               switch(ch){

                              case 1:

                              e1.create();

                              break;

                              case 2:

                              e1.postorder(e1.getroot());

                              break;

                              case 3:

                              e1.nonpostorder(e1.getroot());

                              break;

                             

                                            

               }

}

}