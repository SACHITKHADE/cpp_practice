/*Beginning with an empty binary search tree, Construct binary search 
tree by inserting the values in the order given. After constructing a 
binary tree -
i. Insert new node, ii. Find number of nodes in longest path from 
root, iii. Minimum data value found in the tree, iv. Change a tree so 
that the roles of the left and right pointers are swapped at every node, 
v. Search a value
*/


#include <iostream>
using namespace std;

// struct including data and left-right pointers
struct treenode
{
int data;
treenode *left, *right;
};

// class including data members and functions
class bst
{
// declaration of the root node
treenode *root;

public:
// constructor
bst()
{
root = NULL;
}
// declaration of member functions
treenode *create();
void recursiveinorder(treenode *root);
void recursivepreorder(treenode *root);
void recursivepostorder(treenode *root);
void insert(treenode *root, int num);
int search(treenode *root, int key);
int minimum(treenode *root);
int maximum(treenode *root);
int longestpath(treenode *root);
void swap(treenode *root);
};

// function to create a BST
treenode *bst::create()
{
treenode *curr, *temp;
bool ans;
// loop to continuously insert elements while creation
do
{
curr = new treenode;
cout << "Enter a value to add in BST : " << endl;
cin >> curr->data;

if (root == NULL)
{
root = curr;
}
else
{
temp = root;
// loop to find the correct position of the new element
while (1)
{
if (curr->data < temp->data)
{
if (temp->left == NULL)
{
temp->left = curr;
break;
}
else
{
temp = temp->left;
}
}
else
{
if (temp->right == NULL)
{
temp->right = curr;
break;
}
else
{
temp = temp->right;
}
}
}
}
cout << "Do you want add more elements ?" << endl;
cout << "YES -> Enter 1  |  NO -> Enter 0" << endl;
cin >> ans;
} while (ans == 1);
// returning root node to access it from main function
return root;
}

// recursive function to print BST using inorder traversal
void bst::recursiveinorder(treenode *root)
{
if (root != NULL)
{
// left
recursiveinorder(root->left);
// root
cout << root->data << " ";
// right
recursiveinorder(root->right);
}
}

// recursive function to print BST using preorder traversal
void bst::recursivepreorder(treenode *root)
{
if (root != NULL)
{
// root
cout << root->data << " ";
// left
recursivepreorder(root->left);
// right
recursivepreorder(root->right);
}
}

// recursive function to print BST using postorder traversal
void bst::recursivepostorder(treenode *root)
{
if (root != NULL)
{
// left
recursivepostorder(root->left);
// right
recursivepostorder(root->right);
// root
cout << root->data << " ";
}
}

// function to insert new element after BST is created
void bst::insert(treenode *root, int num)
{
treenode *curr, *temp;
curr = new treenode;
curr->data = num;
if (root == NULL)
{
root = curr;
}
else
{
temp = root;
// loop to find the correct position of the new element
while (1)
{
if (curr->data < temp->data)
{
if (temp->left == NULL)
{
temp->left = curr;
break;
}
else
{
temp = temp->left;
}
}
else
{
if (temp->right == NULL)
{
temp->right = curr;
break;
}
else
{
temp = temp->right;
}
}
}
}
}

// counter for no. of comparisons
int count = 0;
// function to search an element in BST
int bst::search(treenode *root, int key)
{
treenode *temp = root;
if (temp == NULL)
{
count++;
cout << "No. of comparisons : " << count << endl;
return 0;
}

if (temp->data == key)
{
count++;
cout << "No. of comparisons : " << count << endl;
return 1;
}
else
{
if (temp->data > key)
{
count++;
return search(temp->left, key);
}
else
{
count++;
return search(temp->right, key);
}
}
}

// function to return the minimum element on BST
int bst::minimum(treenode *root)
{
treenode *temp;
temp = root;
// traverse to the left-most element
while (temp->left != NULL)
{
temp = temp->left;
}
return temp->data;
}

// function to return the maximum element on BST
int bst::maximum(treenode *root)
{
treenode *temp = root;
// traverse to the right-most element
while (temp->right != NULL)
{
temp = temp->right;
}
return temp->data;
}

// function to find the no. of nodes in longest path of BST
int bst::longestpath(treenode *root)
{
treenode *temp = root;
if (temp == NULL)
{
return 0;
}
else
{
// recursive, upside down approach for both child nodes
// counter incremented everytime a new node is found while traversing to the root
return max(longestpath(temp->left), longestpath(temp->right)) + 1;
}
}

// function to swap the roles of left and right pointers
void bst::swap(treenode *root)
{
if (root == NULL)
{
return;
}
else
{
treenode *temp = root;
// recursion for left and right subtree
swap(root->right);
swap(root->right);

// swapping the left and right pointers using a temp variable
temp = root->left;
root->left = root->right;
root->right = temp;
}
}

// function to display menu
void menu()
{
cout << endl;
cout << "*** BST ***" << endl;
cout << "1. Create a BST" << endl;
cout << "2. Display the BST" << endl;
cout << "3. Insert a new node in BST" << endl;
cout << "4. No. of nodes in the longest path from the root in the BST" << endl;
cout << "5. Minimum data value found in the BST" << endl;
cout << "6. Maximum data value found in the BST" << endl;
cout << "7. Search for a value in BST" << endl;
cout << "8. Swap the roles of left and right pointers in BST" << endl;
cout << "9. Exit" << endl;
cout << endl;
}

int main()
{
// creation of object
bst t1;
// store root node in main function
treenode *r = NULL;
// driver code
int choice;
do
{
menu();
cout << "Enter your choice : " << endl;
cin >> choice;
// switch-case for choosing operations
switch (choice)
{
case 1:
{
r = t1.create();
cout << "BST successfully created." << endl;
break;
}
case 2:
{
cout << "Inorder : ";
t1.recursiveinorder(r);
cout << endl;
cout << "Preorder : ";
t1.recursivepreorder(r);
cout << endl;
cout << "Postorder : ";
t1.recursivepostorder(r);
cout << endl;
break;
}
case 3:
{
int insertkey;
cout << "Enter the value to be inserted : " << endl;
cin >> insertkey;
t1.insert(r, insertkey);
cout << "Element inserted successfully." << endl;
break;
}
case 4:
{
int pathno = t1.longestpath(r);
cout << "The no. of nodes in the longest path from the root in the BST is " << pathno << endl;
break;
}
case 5:
{
int min;
min = t1.minimum(r);
cout << "The minimum element in BST is " << min << endl;
break;
}
case 6:
{
int max = t1.maximum(r);
cout << "The maximum element in BST is " << max << endl;
break;
}
case 7:
{
int searchkey;
cout << "Enter the key to be found : " << endl;
cin >> searchkey;
int searchresult = t1.search(r, searchkey);
if (searchresult == 1)
{
cout << "FOUND" << endl;
}
else
{
cout << "NOT FOUND" << endl;
}
}
case 8:
{
t1.swap(r);
cout << "Swapped" << endl;
break;
}
}
} while (choice < 9);
cout << "Exited" << endl;
return 0;
}