//problem statment:construst an expression tree from the given prefix expreession eg. +__a*bc/def and traversal(non recursive ) and then delet the entire tree
//Roll NO:-48
//Name:- Prathamesh Rathi
//DSA
#include<iostream>
#include<stack>
using namespace std;

bool isoperand(char x)
{
if(x>='A' && x<='Z' || x>='a' && x<='z')
{
return 1;
}
else
{
return 0;
}
}
string PrefixtoPostfix(string prefix)
{
stack<string>s;
for(int i=prefix.length()-1;i>=0;i--)
{
if(isoperand(prefix[i]))
{
string op(1,prefix[i]);
s.push(op);
}
else
{
string op1=s.top();
s.pop();
string op2=s.top();
s.pop();
s.push(op1+op2+prefix[i]);
}
}
return s.top();
}
int main()
{
string prefix,postfix;
cout<<"Enter a prefix expression:";
cin>>prefix;
postfix=PrefixtoPostfix(prefix);
cout<<"Prefix expression is:"<<prefix<<endl;
cout<<"Postfix expression is:"<<postfix<<endl;;
return 0;
}

//OUTPUT:-
kkw@kkw-HP-280-G2-MT-Legacy:~/SE_A_48 DSA$ g++ ASS1.cpp
kkw@kkw-HP-280-G2-MT-Legacy:~/SE_A_48 DSA$ ./a.out
Enter a prefix expression:+ab
Prefix expression is:+ab
Postfix expression is:ab+

