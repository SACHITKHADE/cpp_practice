/*Company maintains employee information as employee ID, name, 
designation and salary. Allow user to add, delete information of 
employee. Display information of particular employee. If employee 
does not exist an appropriate message is displayed. If it is, then the 
system displays the employee details. Use index sequential file to
maintain the data*/

#include <iostream>

#include<fstream>

#include<cstring>

#include<iomanip>

using namespace std;

const int MAX=20;

class Employee

{

 int Employee_ID;

 char name[20],city[20],designation[20];

 int salary;

public:

 Employee()

{

  strcpy(name,"");

  strcpy(city,"");

  strcpy(designation,"");

 

  Employee_ID=salary=0;

}

 Employee(int Employee_ID,char name[MAX],int salary,char designation[MAX],char city[MAX])

 {

  strcpy(this->name,name);

  strcpy(this->city,city);

  strcpy(this->designation,designation);

  this->Employee_ID=Employee_ID;

  this->salary=salary;

 

 }

 int getEmployee_ID()

 {

  return Employee_ID;

 }

 void displayRecord()

 {

 

  cout<<endl<<setw(5)<<Employee_ID<<setw(20)<<name<<setw(5)<<salary<<setw(5)<<designation<<setw(10)<<city;

 }

};

//==========File Operations ===========

class FileOperations

{

 fstream file;

public:

 FileOperations(char* filename)

{

file.open(filename,ios::in|ios::out|ios::ate|ios::binary);

}

 void insertRecord(int Employee_ID, char name[MAX],int salary, char designation[MAX],char city[MAX])

 {

  Employee s1(Employee_ID,name,salary,designation,city);

  file.seekp(0,ios::end);

  file.write((char *)&s1,sizeof(Employee));

  file.clear();

 }

 void displayAll()

 {

  Employee s1;

  file.seekg(0,ios::beg);

  while(file.read((char *)&s1, sizeof(Employee)))

  {

   s1.displayRecord();

  }

  file.clear();

 }

 void displayRecord(int Employee_ID)

 {

  Employee s1;

  file.seekg(0,ios::beg);

  bool flag=false;

  while(file.read((char*)&s1,sizeof(Employee)))

  {

   if(s1.getEmployee_ID()==Employee_ID)

   {

    s1.displayRecord();

    flag=true;

    break;

   }

  }

  if(flag==false)

  {

   cout<<"\nRecord of "<<Employee_ID<<"is not present.";

  }

  file.clear();

 }

 void deleteRecord(int Employee_ID)

 {

  ofstream outFile("new.dat",ios::binary);

  file.seekg(0,ios::beg);

  bool flag=false;

  Employee s1;

 

  while(file.read((char *)&s1, sizeof(Employee)))

  {

   if(s1.getEmployee_ID()==Employee_ID)

   {

    flag=true;

    continue;

   }

   outFile.write((char *)&s1, sizeof(Employee));

  }

  if(!flag)

  {

   cout<<"\nRecord of "<<Employee_ID<<" is not present.";

  }

  file.close();

  outFile.close();

  remove("Employee.dat");

  rename("new.dat","Employee.dat");

  file.open("Employee.dat",ios::in|ios::out|ios::ate|ios::binary);

 }

 ~FileOperations()

 {

  file.close();

  cout<<"\nFile Closed.";

 }

};

int main() {

 ofstream newFile("Employee.dat",ios::app|ios::binary);

  newFile.close();

  FileOperations file((char*)"Employee.dat");

     int Employee_ID,salary,choice=0;

     char designation[MAX];

     char name[MAX],address[MAX];

     while(choice!=5)

     {

         //clrscr();

         cout<<"\n*****Employee Database*****\n";

         cout<<"1) Add New Record\n";

         cout<<"2) Display All Records\n";

         cout<<"3) Display by Employee_ID\n";

         cout<<"4) Deleting a Record\n";

         cout<<"5) Exit\n";

         cout<<"Choose your choice : ";

         cin>>choice;

         switch(choice)

         {

             case 1 : //New Record

               cout<<endl<<"Enter Employee_ID and name : \n";

               cin>>Employee_ID>>name;

               cout<<"Enter salary and designation : \n";

               cin>>salary>>designation;

               cout<<"Enter address : \n";

               cin>>address;

               file.insertRecord(Employee_ID,name,salary,designation,address);

               cout<<"\nRecord Inserted.";

               break;

             case 2 :

              cout<<endl<<setw(5)<<"ROLL"<<setw(20)<<"NAME"<<setw(5)<<"salary"<<setw(20)<<"designation"<<setw(10)<<"CITY";

               file.displayAll();

               break;

             case 3 :

               cout<<"Enter Roll Number";

               cin>>Employee_ID;

                file.displayRecord(Employee_ID);

 

               break;

             case 4:

               cout<<"Enter Employee_ID";

               cin>>Employee_ID;

               file.deleteRecord(Employee_ID);

               break;

            case 5 :break;

         }

 

     }

 

 return 0;

}