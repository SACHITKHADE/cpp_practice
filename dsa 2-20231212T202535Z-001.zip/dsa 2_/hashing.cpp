#include<iostream>
#include<stdlib.h>
#include<string.h>

using namespace std;
int main()
{
	int n,i,j,temp;
	int ar[10];
	int hast[10];
	int k;
	
	cout<<"Enter no of elements";
	cin>>n;
	cout<<"elements:";
	for(i=0;i<n;i++)
	{
	cin>>ar[i];
	}
	for(i=0;i<10;i++)
	{
	hast[i]=0;
	}
	cout<<"array: ";
	for(i=0;i<n;i++) 
	{
	  cout<<ar[i]<<" ";
	}
	for(i=0;i<n;i++)
	{
		k=ar[i]%10;
		for (j=k+1;j%10!=k;j++){
			if hast[j]==0{
				hast[k]=ar[i]
				}
			if j==10{
				j=0
				}
			
	cout<<"\n Hash table is given by	:	\n";
	for(i=0;i<10;i++)
	{
		cout<<"Position["<<i<<"] --> "<<hast[i]<<"\n";
	}
	return 0;
}
