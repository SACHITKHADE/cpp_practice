#include<iostream>
using namespace std;

int hashf(int key){
    return key%10;
}

int main(){
    int a[10]={},b[10],c[10],m,n;
    for(int i=0;i<10;i++){
    b[i]=-1;
    }
    cout<<"enter no of elements : "<<endl;
    cin>>n;
    cout<<"enter the elements : "<<endl;
    for(int i=0;i<n;i++){
        cin>>c[i];
        m=hashf(c[i]);
        if(a[m]==0){
            a[m]=c[i];
        }
        else{
            while(a[m]!=0){
                m=(m+1)%10;
            }
            if(a[m]==0){
                a[m]=c[i];
                
                }
        }
    }
    for(int i=0;i<10;i++){
            if(a[i]%10!=i && a[i]!=0){
            m=a[i]%10;
            b[m]=i;
        }

        }
    
    for(int m=0;m<10;m++){
        cout<<"key : "<<"address : "<<"index : "<<endl;
        cout<<a[m]<<"\t"<<m<<"\t"<<b[m]<<endl;

    }

}
