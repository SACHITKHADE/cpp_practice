#include<iostream>
#include<string.io>
using namespace std;
//consider a data base of 10 clients .make use of hash table to quickly find telephone no. make use of two collision resolution  
int main()
{
int n,i,k;
int a[8];
int hast[5];
int key;
string
cout<<"Enter number of array elements :\n";
cin>>n;
cout<<"Enter array elements :\n";
for(i=0;i<n;i++)
{
	cin>>a[i];
}
cout<<"the elements :\n";
for(i=0;i<n;i++)
{
	cout<<a[i];
}
k=key%10;
return 0;
}


