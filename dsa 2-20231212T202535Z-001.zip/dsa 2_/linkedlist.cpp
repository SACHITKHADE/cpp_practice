///By using linked list create the chainng///


#include<iostream>                                  
using namespace std; 
class  node{ 
    friend class linked_list;
    public:     
    node*next;    
    int data;  
    node(int d){ 
        data =d;
        next=NULL; 
        
           }} ;
        
        
class linked_list{
    public:
         node* ptr,*temp;
            linked_list(){
              
            }
        void hash_table(int  a[10],node *b[10],int n);
        void array_input(int a[10],node* b[10]);    
        void linked_list_display(node* b[10]) ; };        
        
    void linked_list::hash_table(int  a[10],node *b[10],int n){  
        int m,data;
      for(int i=0;i<n;i++){   
          m=a[i]%10; 
        temp=new node(data);
          if(b[m]->data==0){   
              b[m]->data=a[i];
              
          }      
            else{
                
                
                ptr=b[m];
                while(ptr->next!=NULL){
                    ptr=ptr->next;
                }
                if (ptr->next==NULL){
                    ptr->next=temp;
                   temp->data=a[i] ;
                   
                }
            }
              
          
    }
        return linked_list_display(b) ;
    }   
          void linked_list::array_input(int a[10],node* b[10]){   
              int n,data;
              {
                 data=0;}
              for (int i=0;i<10;i++){
                 
                 b[i]=new node(data);
                         }
                                       
                cout<<"enter how many numbers you want "<<endl;
                 cin>>n;
                 for (int i=0;i<n;i++){
                     cout<<"enter "<<"\t"<<i<<"\t"<<"element "<<endl;
                     cin>>a[i];}
                     return hash_table(a,b,n);
          }
          
          void linked_list::linked_list_display ( node*b[10]){
              
              for (int i=0;i<10;i++){
                  cout<<endl;
                  ptr=b[i];
                  cout<<"B["<<i<<"]"<<"->"<<"\t";
                  while (ptr!=NULL){
                     
                      cout<<ptr->data<<"->\t";
                     ptr=ptr->next;
                      
                  }}
                  
                  
          }
          
          
          
          
          int main(){
               int x[10];
              node*y[10];
              linked_list n;
              n.array_input(x,y);
              return 0;
              }
